export interface Chatting{
    id:string;
    content:string;
    created_date:string;
    onlydate:string;
    type:string;
    read_flag:string;
}