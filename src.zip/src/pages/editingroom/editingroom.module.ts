import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditingroomPage } from './editingroom';

@NgModule({
  declarations: [
    EditingroomPage,
  ],
  imports: [
    IonicPageModule.forChild(EditingroomPage),
  ],
})
export class EditingroomPageModule {}
