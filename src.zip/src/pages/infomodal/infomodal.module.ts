import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfomodalPage } from './infomodal';

@NgModule({
  declarations: [
    InfomodalPage,
  ],
  imports: [
    IonicPageModule.forChild(InfomodalPage),
  ],
})
export class InfomodalPageModule {}
